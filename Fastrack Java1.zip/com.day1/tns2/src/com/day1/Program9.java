package com.day1;

public class Program9 {
	
	public static void main(String[] args) {
		
		Program9 n1 = new Program9(); // creating objects
		
		//Accessing instance members(variable+methods)
		
		System.out.println(n1.a); //accessing instance variable through objects
		n1.display(); //accessing instance method through objects
		
		
		System.out.println("**************************************");
		
		// Accessing static members(variable+methods)
		
		System.out.println(Program9.b); // Accessing static variable through class
		Program9.display1(); // By specifying classname.method() we can access static method.
		
	}
}
